const chatBox = document.getElementById("chat-box");
const inputField = document.querySelector("input");
const subjectDropdown = document.getElementById("subject");

// ================= LOAD SUBJECTS =================
async function loadSubjects() {
    try {
        const res = await fetch("/api/subjects");
        const data = await res.json();
        data.subjects.forEach(sub => {
            const option = document.createElement("option");
            option.value = sub;
            option.textContent = sub;
            subjectDropdown.appendChild(option);
        });
    } catch (error) {
        console.error("Error loading subjects:", error);
    }
}

// ================= THEME TOGGLE =================
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const targetTheme = currentTheme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", targetTheme);
    document.getElementById("theme-toggle").innerText = targetTheme === "dark" ? "☀️" : "🌙";
    localStorage.setItem("theme", targetTheme);
}

// ================= CLEAR CHAT =================
function clearChat() {
    chatBox.innerHTML = `
        <div class="bot-message">
            Hello! 👋 I’m your Exam Revision Bot.<br>
            Ask me anything from your notes 📚
        </div>
    `;
}

// ================= ADD MESSAGE =================
function addMessage(message, type) {
    const msgDiv = document.createElement("div");
    msgDiv.classList.add(type === "user" ? "user-message" : "bot-message");

    if (type === "bot") {
        let formatted = message
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n[*\-] (.*?)/g, '<br>• $1')
            .replace(/\n\d\. (.*?)/g, '<br><b>$1</b>')
            .replace(/\n/g, "<br>");
        msgDiv.innerHTML = formatted;
    } else {
        msgDiv.innerText = message;
    }

    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// ================= ASK QUESTION =================
async function askQuestion(customQuery = null) {
    const question = customQuery || inputField.value.trim();
    const subject = subjectDropdown.value;

    if (!question) return;

    if (!customQuery) {
        addMessage(question, "user");
        inputField.value = "";
    }

    const loadingMsg = document.createElement("div");
    loadingMsg.classList.add("bot-message");
    loadingMsg.id = "loading-indicator";
    loadingMsg.innerText = "⏳ Processing technical request...";
    chatBox.appendChild(loadingMsg);
    chatBox.scrollTop = chatBox.scrollHeight;

    try {
        const res = await fetch("/api/ask", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question, subject })
        });

        const data = await res.json();
        const indicator = document.getElementById("loading-indicator");
        if (indicator) chatBox.removeChild(indicator);

        if (data.answer) {
            addMessage(data.answer, "bot");
        } else {
            addMessage("⚠️ Error: " + (data.error || "AI could not respond"), "bot");
        }
    } catch (error) {
        const indicator = document.getElementById("loading-indicator");
        if (indicator) chatBox.removeChild(indicator);
        addMessage("❌ Connection Error", "bot");
    }
}

// ================= ENTER KEY =================
inputField.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
        e.preventDefault();
        askQuestion();
    }
});

// ================= INIT =================
window.onload = function () {
    loadSubjects();
    const savedTheme = localStorage.getItem("theme") || "light";
    document.documentElement.setAttribute("data-theme", savedTheme);
    document.getElementById("theme-toggle").innerText = savedTheme === "dark" ? "☀️" : "🌙";
};